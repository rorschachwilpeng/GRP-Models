# GRP-Models
Building the simulation models for the GRP


2020/1/13
The Simulation Of The Road Traffic:
1. Target the road at the crossroads on the InCity;
2. Build the basic road and the cars model;


2020/1/22

The basic version of Road Traffic Simulation is done:

The Work Done:
1. Drawing the basic map by editing the GaoDe map's Satellite map.

2. Drawing the road

3. Building the 3D version 

4. Building the logic for the cars and the traffic light


The Work Should Continue:
1. Adding the Bus station

2. May adding Electric vehicle ? 

3. Add the frame which can junmp immediately from the logic to the logic/3D


The Work needed invastigate:

1. The probability of turnaround , turn right , turn left , Going stright

2. The location of bus station

3. The time period of the traffic light




